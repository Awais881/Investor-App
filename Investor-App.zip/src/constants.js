export const baseURl = `https://cloud1.sty-server.com/`;
